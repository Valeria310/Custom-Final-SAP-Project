sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("kb.ui.shop.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);